import cv2
import os
import pandas as pd

def take_images(name, enrollment, program, semester):
    if not name or not enrollment:
        print("Name and Enrollment are required!")
        return

    student_details_path = "StudentDetails/studentdetails.csv"
    mapping_path = "StudentDetails/EnrollmentMapping.csv"

    # Load existing mappings or create a new mapping
    if os.path.exists(mapping_path):
        df_map = pd.read_csv(mapping_path)
        enrollment_map = dict(zip(df_map['Enrollment'], df_map['IntID']))
        current_max_id = df_map['IntID'].max()
    else:
        enrollment_map = {}
        current_max_id = 0

    # Assign unique IntID
    if enrollment not in enrollment_map:
        current_max_id += 1
        enrollment_map[enrollment] = current_max_id
        # Append to mapping CSV
        df_new_map = pd.DataFrame([[current_max_id, enrollment]], columns=["IntID", "Enrollment"])
        df_new_map.to_csv(mapping_path, mode='a', header=not os.path.exists(mapping_path), index=False)

    face_classifier = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    cam = cv2.VideoCapture(0)
    sample_num = 0

    # Save in a nested folder
    folder_path = os.path.join("TrainingImage", program, semester, f"{enrollment}-{name}")
    os.makedirs(folder_path, exist_ok=True)

    while True:
        ret, frame = cam.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_classifier.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            sample_num += 1
            face = gray[y:y+h, x:x+w]
            cv2.imwrite(os.path.join(folder_path, f"{name}_{sample_num}.jpg"), face)
            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            cv2.imshow("Capturing Faces", frame)

        if cv2.waitKey(1) == 27 or sample_num >= 50:
            break

    cam.release()
    cv2.destroyAllWindows()

    # Save student details
    df_student = pd.DataFrame([[enrollment, name, program, semester]], columns=["Enrollment", "Name", "Program", "Semester"])
    df_student.to_csv(student_details_path, mode='a', header=not os.path.exists(student_details_path), index=False)

    print(f"Images saved for {name} ({enrollment}) in folder: {folder_path}")
