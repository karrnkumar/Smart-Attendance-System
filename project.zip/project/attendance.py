import tkinter as tk
from tkinter import *
from tkinter import ttk
import os
import pandas as pd
from PIL import ImageTk, Image
import pyttsx3

# Project module imports
import show_attendance
import takeImage
import trainImage
import automaticAttedance


def text_to_speech(user_text):
    engine = pyttsx3.init()
    engine.say(user_text)
    engine.runAndWait()

haarcasecade_path = "haarcascade_frontalface_default.xml"
trainimagelabel_path = "TrainingImageLabel\\Trainner.yml"
trainimage_path = "TrainingImage"
studentdetail_path = "StudentDetails\\studentdetails.csv"
attendance_path = "Attendance"

window = Tk()
window.title("Face recognizer")
window.geometry("1280x720")
dialog_title = "QUIT"
dialog_text = "Are you sure want to close?"
window.configure(background="black")

def del_sc1():
    sc1.destroy()

def err_screen():
    global sc1
    sc1 = tk.Tk()
    sc1.geometry("400x110")
    sc1.title("Warning!!")
    sc1.configure(background="black")
    sc1.resizable(0, 0)
    tk.Label(
        sc1,
        text="Enrollment & Name required!!!",
        fg="yellow",
        bg="black",
        font=("times", 20, " bold "),
    ).pack()
    tk.Button(
        sc1,
        text="OK",
        command=del_sc1,
        fg="yellow",
        bg="black",
        width=9,
        height=1,
        activebackground="Red",
        font=("times", 20, " bold "),
    ).place(x=110, y=50)

def testVal(inStr, acttyp):
    return inStr.isdigit() if acttyp == "1" else True

logo = Image.open("UI_Image/0005.png")
logo = logo.resize((50, 47), Image.Resampling.LANCZOS)
logo1 = ImageTk.PhotoImage(logo)
titl = tk.Label(window, bg="black", relief=RIDGE, bd=10, font=("arial", 35))
titl.pack(fill=X)
l1 = tk.Label(window, image=logo1, bg="black")
l1.place(x=560, y=10)

titl = tk.Label(window, text="FaceTrack", bg="black", fg="sky blue", font=("Lucida Calligraphy", 27, "bold"))
titl.place(x=630, y=12)

a = tk.Label(
    window,
    text="Welcome to AI-Driven Face Recognition Based\nAttendance Management System",
    bg="black",
    fg="gold",
    bd=10,
    font=("arial", 35),
)
a.pack()

ri = Image.open("UI_Image/register.png")
r = ImageTk.PhotoImage(ri)
label1 = Label(window, image=r)
label1.image = r
label1.place(x=100, y=270)

ai = Image.open("UI_Image/attendance.png")
a = ImageTk.PhotoImage(ai)
label2 = Label(window, image=a)
label2.image = a
label2.place(x=980, y=270)

vi = Image.open("UI_Image/verifyy.png")
v = ImageTk.PhotoImage(vi)
label3 = Label(window, image=v)
label3.image = v
label3.place(x=550, y=270)

def TakeImageUI():
    ImageUI = Tk()
    ImageUI.title("Take Student Image..")
    ImageUI.geometry("780x600")
    ImageUI.configure(background="black")
    ImageUI.resizable(0, 0)
    tk.Label(ImageUI, bg="black", relief=RIDGE, bd=10, font=("arial", 35)).pack(fill=X)

    tk.Label(ImageUI, text="Face Registration", bg="black", fg="sky blue", font=("Arial Rounded MT Bold", 30)).place(x=230, y=10)
    tk.Label(ImageUI, text="Enter the Details", bg="black", fg="gold", bd=10, font=("arial", 24)).place(x=250, y=75)

    # Place this inside the TakeImageUI() function, replacing the Enrollment and Name Entry parts

    tk.Label(ImageUI, text="Enrollment No : ", width=12, height=2, bg="black", fg="lime", bd=5,
             font=("oleo script", 16, "bold")).place(x=120, y=260)
    txt1 = tk.Entry(ImageUI, width=20, bd=5, bg="black", fg="white", relief="groove", font=("oleo script", 20),
                    insertbackground="white")
    txt1.place(x=310, y=264)

    tk.Label(ImageUI, text="Name :", width=10, height=2, bg="black", fg="lime", bd=5,
             font=("oleo script", 16, "bold")).place(x=88, y=320)
    txt2 = tk.Entry(ImageUI, width=20, bd=5, bg="black", fg="white", relief=RIDGE, font=("oleo script", 20),
                    insertbackground="white")
    txt2.place(x=310, y=328)

    # Enable blinking cursor on focus
    def focus_enrollment(event):
        txt1.focus_set()

    def focus_name(event):
        txt2.focus_set()

    txt1.bind("<FocusIn>", focus_enrollment)
    txt2.bind("<FocusIn>", focus_name)

    tk.Label(ImageUI, text="Program :", bg="black", fg="lime", font=("oleo script", 16, "bold")).place(x=120, y=150)
    program_cb = ttk.Combobox(ImageUI, font=("oleo script", 18), width=18, state="readonly")
    program_cb.place(x=310, y=154)

    tk.Label(ImageUI, text="Semester :", bg="black", fg="lime", font=("oleo script", 16, "bold")).place(x=120, y=211)
    semester_cb = ttk.Combobox(ImageUI, font=("oleo script", 18), width=18, state="readonly")
    semester_cb.place(x=310, y=210)

    # Load Program and Semesters from course.csv
    df = pd.read_csv("course.csv")
    programs = sorted(df["Program"].unique().tolist())
    program_cb["values"] = programs

    def update_semesters(event=None):
        selected_program = program_cb.get()
        semesters = sorted(df[df["Program"] == selected_program]["Semester"].unique())
        semester_cb["values"] = semesters
        if semesters:
            semester_cb.current(0)

    program_cb.bind("<<ComboboxSelected>>", update_semesters)

    tk.Label(ImageUI, text="Notification :", width=10, height=2, bg="black", fg="lime", bd=5, font=("oleo script", 16, "bold")).place(x=115, y=388)
    message = tk.Label(ImageUI, text="", width=40, height=2, bd=5, bg="black", fg="white", relief="groove", font=("oleo script", 11))
    message.place(x=310, y=392)

    def get_or_create_intid(enrollment):
        mapping_path = "StudentDetails/EnrollmentMapping.csv"
        os.makedirs("StudentDetails", exist_ok=True)
        df_map = pd.read_csv(mapping_path) if os.path.exists(mapping_path) else pd.DataFrame(columns=["Enrollment", "IntID"])
        if enrollment in df_map["Enrollment"].values:
            return int(df_map[df_map["Enrollment"] == enrollment]["IntID"].values[0])
        new_id = df_map["IntID"].max() + 1 if not df_map.empty else 1
        df_map = pd.concat([df_map, pd.DataFrame([{"Enrollment": enrollment, "IntID": new_id}])])
        df_map.to_csv(mapping_path, index=False)
        return new_id

    def take_image():
        enrollment = txt1.get().strip()
        name = txt2.get().strip()
        program = program_cb.get().strip()
        semester = semester_cb.get().strip()

        if not name or not enrollment or not program or not semester:
            err_screen()
            return

        intid = get_or_create_intid(enrollment)
        takeImage.take_images(name, enrollment, program, semester)
        message.config(text=f"Images captured for {name} ({enrollment}) | IntID: {intid}")
        text_to_speech(f"Images captured successfully for {name}")

        txt1.delete(0, "end")
        txt2.delete(0, "end")
        program_cb.set("")
        semester_cb.set("")

    takeImg = tk.Button(ImageUI, text="Take Image", command=take_image, bd=10, font=("oleo script", 18), bg="black", fg="orange", height=2, width=12, relief="raised")
    takeImg.place(x=140, y=470)

    def train_image():
        trainImage.train_image(haarcasecade_path, trainimage_path, trainimagelabel_path, message, text_to_speech)

    trainImg = tk.Button(ImageUI, text="Train Image", command=train_image, bd=10, font=("oleo script", 18), bg="black", fg="orange", height=2, width=12, relief="raised")
    trainImg.place(x=420, y=470)

tk.Button(window, text="Register a new student", command=TakeImageUI, bd=10, font=("oleo script", 16), bg="black", fg="orange", height=2, width=19).place(x=90, y=520)
tk.Button(window, text="Take Attendance", command=lambda: automaticAttedance.subjectChoose(text_to_speech), bd=10, font=("oleo script", 16), bg="black", fg="orange", height=2, width=17).place(x=550, y=520)
tk.Button(window, text="View Attendance", command=lambda: show_attendance.subjectchoose(text_to_speech), bd=10, font=("oleo script", 16), bg="black", fg="orange", height=2, width=17).place(x=1000, y=520)
tk.Button(window, text="EXIT", command=quit, bd=10, font=("oleo script", 16), bg="black", fg="orange", height=2, width=17).place(x=550, y=660)

window.mainloop()
